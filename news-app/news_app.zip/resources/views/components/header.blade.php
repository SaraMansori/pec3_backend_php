<header>

    {{ $slot }}

</header>