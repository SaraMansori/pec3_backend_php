<!doctype html>

<title>News site</title>
<link rel="stylesheet" href="/app.css">

<body>

    {{ $slot }}

</body>